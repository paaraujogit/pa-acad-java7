
public class LojaVideojogos {

    private static int stock;

    public static void main(String[] args) {
        Videojogo playerOne = new Videojogo(
                new Preço(50, 45),
                new Descrição(
                        new Características("Acção", "PS4", Classificação.dozeOuMais, "Asneiras")
                )
        );
        setStock(100);
        venderJogo(playerOne, stock);
    }

    static void setStock(int quantidade) {
        stock = quantidade;
    }

    static void venderJogo(Videojogo playerOne, int stock) {
        /*if (stock == 0) {
            break;
            else
                stock = stock - 1;
        }*/
    }
}

/*Videojogo playerTwo = new Videojogo(
                new Descrição("FIFA", "Português", 365,
                new Classificação("Desporto", "PS4", Idade.trêsOuMais, String "Asneiras")),
                new InfoEdição("EA", "EA Sports"));*/
 /*Videojogo playerThree = new Videojogo(
                new Preço(100, '€'),
                new Descrição("FIFA", "Português", 365),
                new InfoEdição("EA", "EA Sports"));
        Videojogo playerFour = new Videojogo(100, '€', "FIFA", "Português", 365, "EA", "EA Sports");*/
 /*Videojogo playerTwo = new Videojogo();
        Videojogo playerThree = new Videojogo();
        Videojogo playerFour = new Videojogo();
        Videojogo playerFive = new Videojogo();
        Videojogo playerSix = new Videojogo();
        Videojogo playerSeven = new Videojogo();
        Videojogo playerEight = new Videojogo();*/
