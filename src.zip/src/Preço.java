
class Preço {

    private double valor;
    private double valorRecomendado;
    //preço recomendado pela editora

    Preço(double valor, double valorRecomendado) {
        this.valor = valor;
        this.valorRecomendado = valorRecomendado;
    }
}
