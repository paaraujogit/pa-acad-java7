public class StockJogos {
    private int stock;
    
    StockJogos(int stock){
        this.stock = stock;
    }
    
    public int getStock() {
        return stock;
    }
    
}
