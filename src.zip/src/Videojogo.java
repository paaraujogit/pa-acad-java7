class Videojogo {
    private Preço preço;
    private Descrição descrição;
    private InfoEdição infoEdição;
    private InfoSecundária infoSecundária;  
    
    /*Videojogo(Descrição descrição, InfoEdição infoEdição, InfoSecundária infoSecundária){
        this.descrição = descrição;
        this.infoEdição = infoEdição;
        this.infoSecundária = infoSecundária;
    }*/
        
    Videojogo(Preço preço, Descrição descrição) {
        this.preço = preço;
        this.descrição = descrição;
    
    }

    Videojogo(Preço preço, Descrição descrição, InfoEdição infoEdição) {
        this.preço = preço;
        this.descrição = descrição;
        this.infoEdição = infoEdição;
    }

    /*Videojogo(int i, char c, String fifa, String português, int i0, String ea, String ea_Sports) {
        preço = new Preço(i, c);
        descrição = new Descrição(fifa, português, i0);
        infoEdição = new InfoEdição(ea, ea_Sports);
    }*/

        /**
     * @return the preço
     */
    public Preço getPreço() {
        return preço;
    }

    /**
     * @return the descrição
     */
    public Descrição getDescrição() {
        return descrição;
    }

    /**
     * @return the infoEdição
     */
    public InfoEdição getInfoEdição() {
        return infoEdição;
    }

    /**
     * @return the infoSecundária
     */
    public InfoSecundária getInfoSecundária() {
        return infoSecundária;
    }
    
    
}
